package com.example.dietinexerciseout;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class BrowserActivity extends DietActivity {
	ImageButton btnMenu;
	Button butGo, butLinkPush, butLinkSave;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

//		requestWindowFeature(Window.FEATURE_NO_TITLE);
//		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
//				WindowManager.LayoutParams.FLAG_FULLSCREEN);

		setContentView(R.layout.activity_browser);
		createDrawer("ArcGIS Community Map");

		WebView wvMain = (WebView) findViewById(R.id.wvMain);
		wvMain.getSettings().setJavaScriptEnabled(true); // enable javascript

		final Activity activity = this;

		wvMain.setWebViewClient(new WebViewClient() {
			public void onReceivedError(WebView view, int errorCode,
					String description, String failingUrl) {
				Toast.makeText(activity, description, Toast.LENGTH_SHORT)
						.show();
			}
		});

		wvMain.loadUrl("http://www.freshwoodboardshop.com/healthMap/default2.aspx");
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
	}

}
