package com.example.dietinexerciseout;

public class ConsumedBurnedDate {
	String date;
	int consumed;
	int burned;

	public ConsumedBurnedDate(String date, int consumed, int burned) {
		this.date = date;
		this.consumed = consumed;
		this.burned = burned;
	}
}
