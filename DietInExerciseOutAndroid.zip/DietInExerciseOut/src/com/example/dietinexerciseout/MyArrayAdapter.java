package com.example.dietinexerciseout;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MyArrayAdapter extends ArrayAdapter<String> {
	private final Context _context;
	private final Integer[] images;
	private final String[] adapterList;
	private final LayoutInflater inflater;
	private final String selectedItem;

	/*
	 * MyArrayAdapter is created for the Navigation Drawer
	 */
	public MyArrayAdapter(Context context, String[] values, Integer[] images,
			String currentSelectedItemTitle) {
		// row_color_list sets up a generic row.
		super(context, R.layout.row_color_list, values);
		this._context = context;
		// Images to be placed to the left of the text view, used for favorite
		// items, favorites,
		// settings, and share
		this.images = images;
		// The row which is currently selected, will have a different color for
		// the row
		selectedItem = currentSelectedItemTitle;
		// All of the catalogs to go into the table
		adapterList = values;
		inflater = (LayoutInflater) this._context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {

		if (view == null) {
			view = inflater.inflate(R.layout.row_color_list, parent, false);
		}

		view.setId(position);
		view.setBackgroundColor(Color.rgb(35, 168, 109));
		TextView textView = (TextView) view.findViewById(R.id.text_name);
		ImageView image = (ImageView) view.findViewById(R.id.image_color);

		// Home
		if (position == 0) {
			image.setImageResource(images[0]);
			image.setVisibility(View.VISIBLE);
			textView.setText("Home");
			textView.setTextColor(Color.WHITE);
			textView.setTextSize(20);
		} else if (position == 1) {
			// Ate
			image.setImageResource(images[1]);
			image.setVisibility(View.VISIBLE);
			textView.setText("What I ate");
			textView.setTextSize(20);
			textView.setTextColor(Color.WHITE);
		} else if (position == 2) {
			// Drank
			image.setImageResource(images[2]);
			image.setVisibility(View.VISIBLE);
			textView.setText("What I drank");
			textView.setTextSize(20);
			textView.setTextColor(Color.WHITE);
		} else if (position == 3) {
			// Did
			textView.setText("What I did");
			textView.setTextSize(16);
			textView.setTextColor(Color.WHITE);
			image.setImageResource(images[position]);
		} else if (position == 4) {
			// Settings
			textView.setTextSize(20);
			textView.setText("ArcGIS Community Map");
			textView.setTextColor(Color.WHITE);
			image.setImageResource(images[position]);
		} else if (position == 5) {
			// Settings
			textView.setTextSize(20);
			textView.setText("Settings");
			textView.setTextColor(Color.WHITE);
			image.setImageResource(images[position]);
		} else if (position == 6) {
			// Share
			textView.setText("Share");
			textView.setTextSize(16);
			textView.setTextColor(Color.WHITE);
			image.setImageResource(images[position]);
		}

		if (adapterList[position].equalsIgnoreCase(selectedItem)) {
			// Scroll to current position in the table view, does not work
			// currently but not a big rush to get it to work.
			view.setBackgroundColor(Color.rgb(26, 96, 65));
			textView.setTextColor(Color.WHITE);
			image.setImageResource(images[position + 7]);
		}

		return view;
	}
}
