package com.example.dietinexerciseout;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.androidplot.xy.LineAndPointFormatter;
import com.androidplot.xy.SimpleXYSeries;
import com.androidplot.xy.XYPlot;
import com.androidplot.xy.XYSeries;

public class MainActivity extends DietActivity {

	boolean firstTime;
	boolean changedGraph;
	boolean changedWeight;
	int dateRange;
	ArrayList<ConsumedBurnedDate> dataPoints = new ArrayList<ConsumedBurnedDate>();

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		createDrawer("Home");
		firstTime = true;
		changedGraph = false;
		changedWeight = false;
		dateRange = 7;
		new LoadData().execute();
	}

	/**
	 * Async Task to make http call
	 */
	private class LoadData extends AsyncTask<Void, Void, Boolean> {

		@Override
		protected Boolean doInBackground(Void... arg0) {

			String url = "";
			String url2 = "";
			if (changedWeight) {
				url = "http://www.freshwoodboardshop.com/DietInExerciseOut/SetWeight.ashx?userGUID=008FCCAC-6059-442C-BB27-392736932520&weight=194";
				changedWeight = false;
				firstTime = true;
			}

			if (firstTime) {
				url = "http://www.freshwoodboardshop.com/DietInExerciseOut/GetUser.ashx?userGUID=008FCCAC-6059-442C-BB27-392736932520";
				url2 = "http://www.freshwoodboardshop.com/DietInExerciseOut/GetDaily.ashx?userGUID=008FCCAC-6059-442C-BB27-392736932520";
			}
			String url3 = "http://www.freshwoodboardshop.com/DietInExerciseOut/GetDateRange.ashx?userGUID=008FCCAC-6059-442C-BB27-392736932520&duration="
					+ dateRange;

			JSONObject json = new JSONParser().getJSONFromUrl(url);
			JSONObject json3 = new JSONParser().getJSONFromUrl(url3);
			JSONObject json2 = null;
			if (firstTime) {
				json2 = new JSONParser().getJSONFromUrl(url2);
			}

			try {
				if (json != null) {
					JSONObject user = json.getJSONObject("user");
					String userGUID = user.getString("userGUID");
					String userName = user.getString("userName");
					int weight = user.getInt("weight");
					int height = user.getInt("height");
					int age = user.getInt("age");
					String sex = user.getString("sex");

					if (json2 != null) {

						consumed = json2.getInt("consumed");
						dailyBase = json2.getInt("dailyBase");
						exercise = json2.getInt("exercise");
					}
				}

				if (json3 != null) {
					JSONArray activities = json3.getJSONArray("activities");
					dataPoints = new ArrayList<ConsumedBurnedDate>();
					for (int i = 0; i < activities.length(); i++) {
						JSONObject currentActivity = activities
								.getJSONObject(i);
						ConsumedBurnedDate cbd = new ConsumedBurnedDate(
								currentActivity.getString("dateString"),
								currentActivity.getInt("consumed"),
								currentActivity.getInt("burned"));
						dataPoints.add(cbd);
					}
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}

			return null;
		}

		@Override
		protected void onPostExecute(Boolean result) {
			super.onPostExecute(result);

			changedGraph = false;
			createGraph();

			if (firstTime) {
				setUpInformation();
				firstTime = false;
			}
		}

	}

	private void setUpInformation() {
		Spinner spinnerDateRange = (Spinner) findViewById(R.id.spinnerDateRange);
		spinnerDateRange
				.setBackgroundResource(R.drawable.drop_down_not_selected);
		final int[] dateInts = { 2, 3, 4, 5, 6, 7, 14, 21, 30, 60, 90, 120,
				150, 180, 210, 240, 270, 300, 330, 365, 730, 1095 };

		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
				this, R.array.ranges, R.layout.my_spinner_text);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		spinnerDateRange.setAdapter(adapter);
		spinnerDateRange.setSelection(5);
		spinnerDateRange
				.setOnItemSelectedListener(new OnItemSelectedListener() {

					@Override
					public void onItemSelected(AdapterView<?> arg0, View arg1,
							int position, long arg3) {
						dateRange = dateInts[position];
						changedGraph = true;
						new LoadData().execute();
					}

					@Override
					public void onNothingSelected(AdapterView<?> arg0) {

					}
				});

		TextView textConsumed = (TextView) findViewById(R.id.textConsumed);
		textConsumed.setText(Html.fromHtml("Calories Consumed: "
				+ "<font size=\"26\"><b>" + consumed + "</b></font>"));

		TextView textDailyBase = (TextView) findViewById(R.id.textDailyBase);
		textDailyBase.setText(Html
				.fromHtml("Calories Burned Without Exercise: "
						+ "<font size=\"26\"><b>" + dailyBase + "</b></font>"));

		TextView textExercise = (TextView) findViewById(R.id.textExercise);
		textExercise.setText(Html.fromHtml("Calories Burned From Exercise: "
				+ "<font size=\"26\"><b>" + exercise + "</b></font>"));

		int difference = dailyBase + exercise;
		difference -= consumed;
		TextView textDifference = (TextView) findViewById(R.id.textDifference);
		textDifference.setText(Html.fromHtml("Calories Remaining to Consume: "
				+ "<font size=\"26\"><b>" + difference + "</b></font>"));

		Button weightSubmit = (Button) findViewById(R.id.buttonSubmitWeight);
		weightSubmit.setBackgroundResource(R.drawable.button);
		weightSubmit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				EditText textWeight = (EditText) findViewById(R.id.editTextCurrentWeight);
				new LoadData().execute();
			}
		});

		EditText textWeight = (EditText) findViewById(R.id.editTextCurrentWeight);
		textWeight.setBackgroundResource(R.drawable.edit_text);
		textWeight.setTextColor(Color.WHITE);
		textWeight.setHint("Change it!");
	}

	protected void createGraph() {
		// initialize our XYPlot reference:
		XYPlot plot = (XYPlot) findViewById(R.id.simplePlot);
		plot.clear();

		ArrayList<Integer> burnedCalories = new ArrayList<Integer>();
		ArrayList<Integer> consumedCalories = new ArrayList<Integer>();
		ArrayList<Integer> xval = new ArrayList<Integer>();
		ArrayList<String> date = new ArrayList<String>();
		for (int i = 0; i < dataPoints.size(); i++) {
			ConsumedBurnedDate cbd = dataPoints.get(i);
			burnedCalories.add(cbd.burned);
			consumedCalories.add(cbd.consumed);
			date.add(cbd.date);
			xval.add(i);
		}

		XYSeries series1 = new SimpleXYSeries(xval, consumedCalories, "");

		XYSeries series2 = new SimpleXYSeries(xval, burnedCalories, "");

		LineAndPointFormatter series1Format = new LineAndPointFormatter();
		series1Format.getFillPaint().setColor(Color.TRANSPARENT);
		series1Format.getLinePaint().setColor(Color.RED);
		series1Format.getVertexPaint().setColor(Color.TRANSPARENT);
		// add a new series' to the xyplot:
		plot.addSeries(series1, series1Format);

		// same as above:
		LineAndPointFormatter series2Format = new LineAndPointFormatter();
		series2Format.getFillPaint().setColor(Color.TRANSPARENT);
		series2Format.getLinePaint().setColor(Color.GREEN);
		series2Format.getVertexPaint().setColor(Color.TRANSPARENT);
		plot.addSeries(series2, series2Format);

		// Remove unwanted color
		plot.getBackgroundPaint().setColor(Color.TRANSPARENT);
		plot.getBorderPaint().setColor(Color.TRANSPARENT);
		plot.getLegendWidget().setVisible(false);
		plot.getTitleWidget().setVisible(false);
		plot.getGraphWidget().getBackgroundPaint().setColor(Color.TRANSPARENT);
		plot.getGraphWidget().getDomainGridLinePaint()
				.setColor(Color.TRANSPARENT);
		plot.getGraphWidget().getDomainSubGridLinePaint()
				.setColor(Color.TRANSPARENT);
		plot.getGraphWidget().getGridBackgroundPaint()
				.setColor(Color.TRANSPARENT);
		plot.getGraphWidget().getRangeGridLinePaint()
				.setColor(Color.TRANSPARENT);
		plot.getGraphWidget().getRangeSubGridLinePaint()
				.setColor(Color.TRANSPARENT);

		plot.setDomainValueFormat(new GraphXLabelFormat(date));
		plot.getGraphWidget().setClippingEnabled(false);
		plot.getGraphWidget().setMarginBottom(100);
		plot.getGraphWidget().setGridPaddingRight(30);

		plot.redraw();
	}
}
