package com.example.dietinexerciseout;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class DietActivity extends Activity {

	MyArrayAdapter listAdapter;
	DrawerLayout mDrawerLayout;
	ListView mDrawerList;
	ActionBarDrawerToggle mDrawerToggle;
	CharSequence mDrawerTitle;
	CharSequence mTitle;
	String userGUID;
	String userName;
	int weight;
	int height;
	int age;
	String sex;
	int consumed;
	int dailyBase;
	int exercise;
	String phoneNumber;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	protected void createDrawer(String title) {
		// mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
		mDrawerList = (ListView) findViewById(R.id.left_drawer);

		// Shadding the area behind the drawer which is still visible to the
		// user
		/*
		 * mDrawerLayout.setDrawerShadow(R.drawable.drawer_shadow,
		 * GravityCompat.START);
		 * 
		 * mDrawerList.setDivider(null); mDrawerList.setDividerHeight(1);
		 */
		// resultForAdapter is all of the string options which will be in the
		// drawer
		String[] resultForAdapter = { "Home", "What I ate", "What I drank",
				"What I did", "ArcGIS Community Map", "Settings", "Share" };
		// the images used for favorites/ share/ and settings
		Integer[] imagesForAdapter = { R.drawable.home, R.drawable.apple,
				R.drawable.water_bottle, R.drawable.shoe, R.drawable.browser,
				R.drawable.settings, R.drawable.share, R.drawable.home_dark,
				R.drawable.apple_dark, R.drawable.watter_bottle_dark,
				R.drawable.shoe_dark, R.drawable.browser_dark,
				R.drawable.settings_dark, R.drawable.share_dark };

		// Create the drawer with an array adapter
		listAdapter = new MyArrayAdapter(this, resultForAdapter,
				imagesForAdapter, title);

		mDrawerList.setAdapter(listAdapter);
		mDrawerList.setOnItemClickListener(new DrawerItemClickListener());

		// ActionBarDrawerToggle ties together the the proper interactions
		// between the sliding drawer and the action bar app icon
		/*
		 * mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
		 * R.drawable.ic_drawer, 0, 0) { public void onDrawerClosed(View view) {
		 * getActionBar().setTitle(getTitle()); invalidateOptionsMenu(); }
		 * 
		 * public void onDrawerOpened(View drawerView) {
		 * getActionBar().setTitle(getTitle()); invalidateOptionsMenu(); } };
		 * mDrawerLayout.setDrawerListener(mDrawerToggle);
		 * 
		 * getActionBar().setDisplayHomeAsUpEnabled(true);
		 */
	}

	/*
	 * @Override public boolean onOptionsItemSelected(MenuItem item) { // The
	 * action bar home/up action should open or close the drawer. //
	 * ActionBarDrawerToggle will take care of this. if
	 * (mDrawerToggle.onOptionsItemSelected(item)) { return true; } return
	 * super.onOptionsItemSelected(item); }
	 */
	private class DrawerItemClickListener implements
			ListView.OnItemClickListener {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			if (position == 0) {
				// Home
				Intent i = new Intent(DietActivity.this, MainActivity.class);
				startActivity(i);
			} else if (position == 1) {
				// Ate
				Intent i = new Intent(DietActivity.this, AteActivity.class);
				startActivity(i);
			} else if (position == 2) {
				// Drink
				Intent i = new Intent(DietActivity.this, DrinkActivity.class);
				startActivity(i);
			} else if (position == 3) {
				// Did
				Intent i = new Intent(DietActivity.this, DidActivity.class);
				startActivity(i);
			} else if (position == 4) {
				// User selected settings activity
				Intent i = new Intent(DietActivity.this, BrowserActivity.class);
				startActivity(i);
			} else if (position == 5) {
				// User selected settings activity
				Intent i = new Intent(DietActivity.this, SettingsActivity.class);
				startActivity(i);
			} else if (position == 6) {
				// // User chose to share the selected graph
				// View content = findViewById(R.id.layoutHome);
				// if (content == null)
				// return;
				//
				// // Take a photo of the HomeActivity.java current state
				// content.setDrawingCacheEnabled(true);
				// Bitmap bitmap = content.getDrawingCache();
				//
				// File sdCardDirectory = Environment
				// .getExternalStorageDirectory();
				// File image = new File(sdCardDirectory,
				// "arizonaEconomyScreenshot.png");
				//
				// FileOutputStream outStream;
				// try {
				//
				// outStream = new FileOutputStream(image);
				// bitmap.compress(Bitmap.CompressFormat.PNG, 100, outStream);
				//
				// outStream.flush();
				// outStream.close();
				// } catch (FileNotFoundException e) {
				// e.printStackTrace();
				// } catch (IOException e) {
				// e.printStackTrace();
				// }
				//
				// // Share the content
				// Intent sharingIntent = new Intent(
				// android.content.Intent.ACTION_SEND);
				// // Allowing the share intent to include a png image
				// sharingIntent.setType("image/png");
				//
				// // Share text, short enough to be used for Twitter
				// String shareBody =
				// "I thought you might like this economic graph from Arizona's Economy. You can learn more about this graph at http://azeconomy.org/";
				//
				// // Title, if available
				// sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,
				// "Economic Graph");
				// sharingIntent.putExtra(android.content.Intent.EXTRA_STREAM,
				// Uri.fromFile(image));
				// sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT,
				// startActivity(Intent.createChooser(sharingIntent,
				// "Share via"));

			}
		}
	}

	/*
	 * Used for Navigation Drawer
	 */
	/*
	 * @Override public void setTitle(CharSequence title) { mTitle = title;
	 * getActionBar().setTitle(mTitle); }
	 * 
	 * /* Used for Navigation Drawer
	 */
	/*
	 * @Override public void onConfigurationChanged(Configuration newConfig) {
	 * super.onConfigurationChanged(newConfig); // Pass any configuration change
	 * to the drawer toggles if (mDrawerToggle == null) return;
	 * mDrawerToggle.onConfigurationChanged(newConfig); }
	 */

}
