package com.example.dietinexerciseout;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class SettingsActivity extends DietActivity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.settings_activity);
		createDrawer("Settings");

		EditText heightText = (EditText) findViewById(R.id.editTextHeight);
		heightText.setBackgroundResource(R.drawable.edit_text);
		heightText.setTextColor(Color.WHITE);

		EditText weightText = (EditText) findViewById(R.id.editTextWeight);
		weightText.setBackgroundResource(R.drawable.edit_text);
		weightText.setTextColor(Color.WHITE);

		EditText ageText = (EditText) findViewById(R.id.editTextAge);
		ageText.setBackgroundResource(R.drawable.edit_text);
		ageText.setTextColor(Color.WHITE);

		EditText phoneText = (EditText) findViewById(R.id.editTextNumber);
		phoneText.setBackgroundResource(R.drawable.edit_text);
		phoneText.setTextColor(Color.WHITE);

		new LoadData().execute();
	}

	private class LoadData extends AsyncTask<Void, Void, Boolean> {

		@Override
		protected Boolean doInBackground(Void... arg0) {

			String url = "http://www.freshwoodboardshop.com/DietInExerciseOut/GetUser.ashx?userGUID=008FCCAC-6059-442C-BB27-392736932520";

			JSONObject json = new JSONParser().getJSONFromUrl(url);

			try {
				if (json == null) {
					return null;
				}
				JSONObject user = json.getJSONObject("user");
				weight = user.getInt("weight");
				height = user.getInt("height");
				age = user.getInt("age");
				phoneNumber = user.getString("mobile");
			} catch (JSONException e) {
				e.printStackTrace();
			}

			return null;
		}

		@Override
		protected void onPostExecute(Boolean result) {
			super.onPostExecute(result);

			EditText heightText = (EditText) findViewById(R.id.editTextHeight);
			heightText.setText(height + "");
			heightText.setBackgroundResource(R.drawable.edit_text);
			EditText weightText = (EditText) findViewById(R.id.editTextWeight);
			weightText.setText(weight + "");
			weightText.setBackgroundResource(R.drawable.edit_text);
			EditText ageText = (EditText) findViewById(R.id.editTextAge);
			ageText.setText(age + "");
			ageText.setBackgroundResource(R.drawable.edit_text);
			EditText phone = (EditText) findViewById(R.id.editTextNumber);
			phone.setText(phoneNumber + "");
			phone.setBackgroundResource(R.drawable.edit_text);

			Button update = (Button) findViewById(R.id.buttonUpdate);
			update.setBackgroundResource(R.drawable.button);
			update.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					Intent i = new Intent(SettingsActivity.this,
							MainActivity.class);
					startActivity(i);
				}
			});

		}

	}
}
