package com.example.dietinexerciseout;

public class Food {

	String id;
	String description;
	String portionDescription;

	Food(String id, String description, String portionDescription) {
		this.id = id;
		this.description = description;
		this.portionDescription = portionDescription;
	}
}
