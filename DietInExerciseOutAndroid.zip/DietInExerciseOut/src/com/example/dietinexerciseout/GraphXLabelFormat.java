package com.example.dietinexerciseout;

import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import java.util.ArrayList;

public class GraphXLabelFormat extends Format {

	private static final long serialVersionUID = -3117379713055846151L;
	ArrayList<String> dates;

	public GraphXLabelFormat(ArrayList<String> date) {
		dates = date;
	}

	@Override
	public StringBuffer format(Object object, StringBuffer buffer,
			FieldPosition field) {
		int parsedInt = Math.round(Float.parseFloat(object.toString()));
		String labelString = dates.get(parsedInt);

		buffer.append(labelString);
		return buffer;
	}

	@Override
	public Object parseObject(String string, ParsePosition position) {
		return dates.indexOf(string);
	}
}
