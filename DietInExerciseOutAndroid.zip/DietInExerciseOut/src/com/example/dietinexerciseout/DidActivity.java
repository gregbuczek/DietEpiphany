package com.example.dietinexerciseout;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class DidActivity extends DietActivity {
	String submittingFood;
	boolean food;
	boolean consumed;
	ArrayList<Food> foodItems = new ArrayList<Food>();
	String portionsConsumed;
	String itemConsumedId;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.did_activity);
		createDrawer("What I did");

		EditText foodItem = (EditText) findViewById(R.id.editTextFoodItem);
		foodItem.setBackgroundResource(R.drawable.edit_text);

		Button submit = (Button) findViewById(R.id.buttonSubmitFood);
		submit.setBackgroundResource(R.drawable.button);
		submit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				EditText foodItem = (EditText) findViewById(R.id.editTextFoodItem);
				submittingFood = foodItem.getText().toString();
				new LoadData().execute();

				food = true;
				consumed = false;
			}
		});
	}

	private class LoadData extends AsyncTask<Void, Void, Boolean> {

		@Override
		protected Boolean doInBackground(Void... arg0) {

			String url = "";
			if (food) {
				url = "http://www.freshwoodboardshop.com/DietInExerciseOut/GetExercise.ashx?searchText="
						+ submittingFood;
			} else if (consumed) {
				url = "http://www.freshwoodboardshop.com/DietInExerciseOut/AddConsume.ashx?userGUID=008FCCAC-6059-442C-BB27-392736932520&foodID="
						+ itemConsumedId + "&portions=" + portionsConsumed;
				consumed = false;
			}

			JSONObject json = new JSONParser().getJSONFromUrl(url);

			try {
				if (json == null) {
					return null;
				}

				if (food) {
					JSONArray foods = json.getJSONArray("exercises");

					for (int i = 0; i < foods.length(); i++) {
						JSONObject currentFoodItem = foods.getJSONObject(i);
						Food currentFood = new Food(
								currentFoodItem.getString("id"),
								currentFoodItem.getString("exerciseType"), "");
						foodItems.add(currentFood);
					}

				}
			} catch (JSONException e) {
				e.printStackTrace();
			}

			return null;
		}

		@Override
		protected void onPostExecute(Boolean result) {
			super.onPostExecute(result);
			if (food) {
				setUpSpinner();
				food = false;
			} else {

				AlertDialog.Builder builder = new AlertDialog.Builder(
						DidActivity.this);
				builder.setTitle("Success!");
				builder.setMessage("You have burned some calories! Would you like to add another exercise?");
				builder.setPositiveButton("Yes",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								EditText foodItem = (EditText) findViewById(R.id.editTextFoodItem);
								foodItem.setText("");
								Spinner spinner = (Spinner) findViewById(R.id.spinnerFoodResults);
								spinner.setVisibility(View.GONE);
								Button consumeButton = (Button) findViewById(R.id.buttonConsume);
								consumeButton.setVisibility(View.GONE);
								EditText portions = (EditText) findViewById(R.id.editTextPortions);
								portions.setVisibility(View.GONE);
								portions.setText("");

							}
						});
				builder.setNegativeButton("Return home",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								Intent i = new Intent(DidActivity.this,
										MainActivity.class);
								startActivity(i);
							}
						});
				// Precent the user from clicking anywhere on the page to cancel
				// the
				// agreement
				builder.setCancelable(false);
				builder.show();

			}
		}

		private void setUpSpinner() {
			Spinner spinner = (Spinner) findViewById(R.id.spinnerFoodResults);
			spinner.setBackgroundResource(R.drawable.drop_down_not_selected);

			String[] values = new String[foodItems.size()];
			for (int i = 0; i < foodItems.size(); i++) {
				values[i] = foodItems.get(i).description + ", "
						+ foodItems.get(i).portionDescription;
			}

			ArrayAdapter<String> adapter = new ArrayAdapter<String>(
					DidActivity.this, android.R.layout.simple_spinner_item,
					values);
			adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner.setAdapter(adapter);
			spinner.setVisibility(View.VISIBLE);
			EditText portions = (EditText) findViewById(R.id.editTextPortions);
			portions.setVisibility(View.VISIBLE);
			portions.setBackgroundResource(R.drawable.edit_text);

			Button consumeButton = (Button) findViewById(R.id.buttonConsume);
			consumeButton.setBackgroundResource(R.drawable.button);
			consumeButton.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					EditText portions = (EditText) findViewById(R.id.editTextPortions);
					portionsConsumed = portions.getText().toString();
					Spinner spinner = (Spinner) findViewById(R.id.spinnerFoodResults);
					itemConsumedId = foodItems.get(spinner
							.getSelectedItemPosition()).id;
					consumed = true;
					new LoadData().execute();
				}
			});
			consumeButton.setVisibility(View.VISIBLE);
		}
	}
}
