﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace DietInExerciseOut
{
    /// <summary>
    /// Summary description for GetExercise
    /// </summary>
    public class GetExercise : IHttpHandler
    {
        private DBFunctions dbFunctions = new DBFunctions();
        public void ProcessRequest(HttpContext context)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            String json = "";
            String searchText = context.Request["searchText"] ?? String.Empty;
            CallResponse cr = new CallResponse();
            cr.response = "success";
            List<Exercise> exercisesFromDB = dbFunctions.getExercises(searchText);
            foreach (Exercise exerciseFromDB in exercisesFromDB)
            {
                LExercise lex = new LExercise();
                lex.exerciseType = exerciseFromDB.exerciseType;
                lex.id = exerciseFromDB.ID;
                cr.exercises.Add(lex);

            }
            cr.count = cr.exercises.Count();
            json = ser.Serialize(cr);
            context.Response.Clear();
            context.Response.ContentType = "application/json; charset=utf-8";
            context.Response.Write(json);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
        public class CallResponse
        {
            public String response = "";
            public Int32 count = 0;
            public List<LExercise> exercises = new List<LExercise>();
        }

        public class LExercise
        {
            public Int32 id = 0;
            public String exerciseType = "";
        }
    }
}