﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace DietInExerciseOut
{
    /// <summary>
    /// Summary description for GetUser
    /// </summary>
    public class GetUser : IHttpHandler
    {

        private DBFunctions dbFunctions = new DBFunctions();
        public void ProcessRequest(HttpContext context)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            String json = "";
            String userGUID = context.Request["userGUID"] ?? String.Empty;
            UserResponse ur = new UserResponse();
            ur.response = "success";
            ur.user = dbFunctions.getUser(userGUID);
            json = ser.Serialize(ur);
            context.Response.Clear();
            context.Response.ContentType = "application/json; charset=utf-8";
            context.Response.Write(json);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        public class UserResponse
        {
            public String response = "";
            public User user = new User();
        }

    }
}