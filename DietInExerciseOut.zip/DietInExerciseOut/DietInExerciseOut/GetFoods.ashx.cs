﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace DietInExerciseOut
{
    /// <summary>
    /// Summary description for GetFoods
    /// </summary>
    public class GetFoods : IHttpHandler
    {

        private DBFunctions dbFunctions = new DBFunctions();
        public void ProcessRequest(HttpContext context)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            String json = "";
            String searchText = context.Request["searchText"] ?? String.Empty;
            CallResponse cr = new CallResponse();
            cr.response = "success";
            List<ABBREV> foodsFromDB = dbFunctions.getFoods(searchText);
            foreach (ABBREV foodFromDB in foodsFromDB)
            {
                Food food = new Food();
                food.description = foodFromDB.Shrt_Desc.Replace(System.Environment.NewLine, "");
                food.id = foodFromDB.NDB_No;
                food.portionDescription = foodFromDB.GmWt_Desc1;
                cr.foods.Add(food);

            }
            cr.count = cr.foods.Count();
            json = ser.Serialize(cr);
            context.Response.Clear();
            context.Response.ContentType = "application/json; charset=utf-8";
            context.Response.Write(json);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
        public class CallResponse
        {
            public String response = "";
            public Int32 count = 0;
            public List<Food> foods = new List<Food>();
        }

        public class Food
        {
            public String id = "";
            public String description = "";
            public String portionDescription = "";
        }
    }
}