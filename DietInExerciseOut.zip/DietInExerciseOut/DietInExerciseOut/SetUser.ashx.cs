﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace DietInExerciseOut
{
    /// <summary>
    /// Summary description for SetUser
    /// </summary>
    public class SetUser : IHttpHandler
    {

        private DBFunctions dbFunctions = new DBFunctions();
        public void ProcessRequest(HttpContext context)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            String json = "";
            String userGUID = context.Request["userGUID"] ?? String.Empty;
            String userName = context.Request["userName"] ?? String.Empty;
            String weight = context.Request["weight"] ?? String.Empty;
            String height = context.Request["height"] ?? String.Empty;
            String age = context.Request["age"] ?? String.Empty;
            String sex = context.Request["sex"] ?? String.Empty;
            String mobile = context.Request["mobile"] ?? String.Empty;

            User user = dbFunctions.getUser(userGUID);
            user.age = Convert.ToInt32(age);
            user.height = Convert.ToInt32(height);
            user.sex = sex;
            user.userName = userName;
            user.mobile = mobile;
            user.weight = Convert.ToInt32(weight);
            dbFunctions.updateUser(user);
            SimpleResponse sr = new SimpleResponse();
            sr.response = "success";
            json = ser.Serialize(sr);
            context.Response.Clear();
            context.Response.ContentType = "application/json; charset=utf-8";
            context.Response.Write(json);

        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        public class SimpleResponse
        {
            public String response = "success";
        }

    }
}