﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.IO;
using System.Text;

namespace DietInExerciseOut
{
    /// <summary>
    /// Summary description for AddConsume
    /// </summary>
    public class AddConsume : IHttpHandler
    {

        private DBFunctions dbFunctions = new DBFunctions();
        public void ProcessRequest(HttpContext context)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            String json = "";
            String userGUID = context.Request["userGUID"] ?? String.Empty;
            String foodID = context.Request["foodID"] ?? String.Empty;
            String portions = context.Request["portions"] ?? String.Empty;
            DateTime timeStamp = DateTime.Now;
            String dateTimeSerial = timeStamp.ToString("yyyyMMddhhmm");
            ABBREV foodConsumed = dbFunctions.getFood(foodID);
            Int32 calloriesConsumed = Convert.ToInt32(Math.Round(Convert.ToInt32(foodConsumed.Energ_Kcal) * Convert.ToSingle(portions)));

            Consume consume = new Consume();
            consume.consumeGUID = Guid.NewGuid().ToString();
            consume.userGUID = userGUID;
            consume.dateTimeStamp = timeStamp;
            consume.NDB_No = foodConsumed.NDB_No;
            consume.portion = Convert.ToInt32(portions);
            consume.calories = calloriesConsumed;
            consume.shortDescription = foodConsumed.Shrt_Desc;
            dbFunctions.addConsume(consume);

            var http = (HttpWebRequest)WebRequest.Create(new Uri(dbFunctions.MHEALTHBASE));
            //http.Accept = "application/json";
            http.ContentType = "text/json";
            http.Method = "POST";

            string jsonOut = "[" + new JavaScriptSerializer().Serialize(new
            {
                timestamp = dateTimeSerial,
                name = "foodCalories",
                value = calloriesConsumed
            }) + "]";
            ASCIIEncoding encoding = new ASCIIEncoding();
            Byte[] bytes = encoding.GetBytes(jsonOut);

            Stream newStream = http.GetRequestStream();
            newStream.Write(bytes, 0, bytes.Length);
            newStream.Close();

            var response = http.GetResponse();
            var stream = response.GetResponseStream();
            var sr = new StreamReader(stream);
            var content = sr.ReadToEnd();

            http = (HttpWebRequest)WebRequest.Create(new Uri(dbFunctions.MHEALTHBASE));
            //http.Accept = "application/json";
            http.ContentType = "text/json";
            http.Method = "POST";

            jsonOut = "[" + new JavaScriptSerializer().Serialize(new
            {
                timestamp = dateTimeSerial,
                name = "foodPortion",
                value = portions
            }) + "]";
            encoding = new ASCIIEncoding();
            bytes = encoding.GetBytes(jsonOut);

            newStream = http.GetRequestStream();
            newStream.Write(bytes, 0, bytes.Length);
            newStream.Close();

            response = http.GetResponse();
            stream = response.GetResponseStream();
            sr = new StreamReader(stream);
            content = sr.ReadToEnd();

            http = (HttpWebRequest)WebRequest.Create(new Uri(dbFunctions.MHEALTHBASE));
            //http.Accept = "application/json";
            http.ContentType = "text/json";
            http.Method = "POST";

            jsonOut = "[" + new JavaScriptSerializer().Serialize(new
            {
                timestamp = dateTimeSerial,
                name = "foodDescription",
                value = foodConsumed.Shrt_Desc
            }) + "]";
            encoding = new ASCIIEncoding();
            bytes = encoding.GetBytes(jsonOut);

            newStream = http.GetRequestStream();
            newStream.Write(bytes, 0, bytes.Length);
            newStream.Close();

            response = http.GetResponse();
            stream = response.GetResponseStream();
            sr = new StreamReader(stream);
            content = sr.ReadToEnd();



            CallResponse cr = new CallResponse();
            cr.response = "success";
            cr.calloriesConsumed = calloriesConsumed;
            json = ser.Serialize(cr);
            context.Response.Clear();
            context.Response.ContentType = "application/json; charset=utf-8";
            context.Response.Write(json);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
        public class CallResponse
        {
            public String response = "";
            public Int32 calloriesConsumed = 0;
        }

    }
}