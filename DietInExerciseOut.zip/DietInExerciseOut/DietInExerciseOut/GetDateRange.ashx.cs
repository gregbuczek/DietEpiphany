﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace DietInExerciseOut
{
    /// <summary>
    /// Summary description for GetDateRange
    /// </summary>
    public class GetDateRange : IHttpHandler
    {

        private DBFunctions dbFunctions = new DBFunctions();
        public void ProcessRequest(HttpContext context)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            String json = "";
            String userGUID = context.Request["userGUID"] ?? String.Empty;
            String duration = context.Request["duration"] ?? String.Empty;
            Int32 daysToGoBack = Convert.ToInt32(duration);
            Int32 daysGoneBack = 0;
            Int32 dailyBase = dbFunctions.getUserBase(userGUID);
            CallResponse cr = new CallResponse();
            cr.response = "success";
            daysToGoBack--;
            while (daysToGoBack >= 0)
            {
                DateTime currentDateInLoop = DateTime.Now.AddDays(daysToGoBack * -1);
                Int32 totalCaloriesConsumed = 0;
                Int32 totalCaloriesBurned = 0;
                List<Consume> consumes = dbFunctions.getConsumedOnDate(userGUID, currentDateInLoop);
                foreach (Consume consume in consumes) totalCaloriesConsumed += consume.calories;
                List<Workout> workouts = dbFunctions.getWorkoutsOnDate(userGUID, currentDateInLoop);
                foreach (Workout workout in workouts) totalCaloriesBurned += workout.calories;

                DailyActivity da = new DailyActivity();
                da.dateString = currentDateInLoop.ToString("yyyy-MM-dd");
                da.consumed = totalCaloriesConsumed;
                da.burned = totalCaloriesBurned + dailyBase;
                cr.activities.Add(da);
                daysToGoBack--;
            }
            json = ser.Serialize(cr);
            context.Response.Clear();
            context.Response.ContentType = "application/json; charset=utf-8";
            context.Response.Write(json);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
        public class CallResponse
        {
            public String response = "";
            public List<DailyActivity> activities = new List<DailyActivity>();
        }

        public class DailyActivity
        {
            public String dateString = "";
            public Int32 consumed = 0;
            public Int32 burned = 0;
        }

    }
}