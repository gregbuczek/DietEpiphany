﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace DietInExerciseOut
{
    /// <summary>
    /// Summary description for AddFoodDrink
    /// </summary>
    public class AddFoodDrink : IHttpHandler
    {

        private DBFunctions dbFunctions = new DBFunctions();
        public void ProcessRequest(HttpContext context)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            String json = "";
            String description = context.Request["description"] ?? String.Empty;
            String portionDescription = context.Request["portionDescription"] ?? String.Empty;
            String calories = context.Request["calories"] ?? String.Empty;
            String newGUID = Guid.NewGuid().ToString();
            ABBREV abb = new ABBREV();
            abb.NDB_No = newGUID;
            abb.Shrt_Desc = description;
            abb.GmWt_Desc1 = portionDescription;
            abb.Energ_Kcal = Convert.ToInt32(calories);
            dbFunctions.addFood(abb);
            CallResponse cr = new CallResponse();
            cr.id = newGUID;
            cr.response = "success";
            json = ser.Serialize(cr);
            context.Response.Clear();
            context.Response.ContentType = "application/json; charset=utf-8";
            context.Response.Write(json);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
        public class CallResponse
        {
            public String response = "";
            public String id = "";
        }
    }
}