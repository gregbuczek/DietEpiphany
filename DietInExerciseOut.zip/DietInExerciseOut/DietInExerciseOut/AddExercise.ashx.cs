﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace DietInExerciseOut
{
    /// <summary>
    /// Summary description for AddExercise
    /// </summary>
    public class AddExercise : IHttpHandler
    {
        private DBFunctions dbFunctions = new DBFunctions();
        public void ProcessRequest(HttpContext context)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            String json = "";
            String exerciseType = context.Request["exerciseType"] ?? String.Empty;
            String calPerPound = context.Request["calPerPound"] ?? String.Empty;
            Exercise exercise = new Exercise();
            exercise.exerciseType = exerciseType;
            exercise.calPerPound = Convert.ToSingle(calPerPound);
            dbFunctions.addExercise(exercise);

            CallResponse cr = new CallResponse();
            cr.id = exercise.ID;
            cr.response = "success";
            json = ser.Serialize(cr);
            context.Response.Clear();
            context.Response.ContentType = "application/json; charset=utf-8";
            context.Response.Write(json);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
        public class CallResponse
        {
            public String response = "";
            public Int32 id = 0;
        }
    }
}