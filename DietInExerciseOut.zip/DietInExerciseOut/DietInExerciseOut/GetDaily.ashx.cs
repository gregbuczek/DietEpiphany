﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace DietInExerciseOut
{
    /// <summary>
    /// Summary description for GetDaily
    /// </summary>
    public class GetDaily : IHttpHandler
    {
        private DBFunctions dbFunctions = new DBFunctions();
        public void ProcessRequest(HttpContext context)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            String json = "";
            String userGUID = context.Request["userGUID"] ?? String.Empty;
            Int32 totalCaloriesConsumed = 0;
            Int32 totalCaloriesBurned = 0;
            List<Consume> consumes = dbFunctions.getConsumedOnDate(userGUID, DateTime.Now);
            foreach (Consume consume in consumes) totalCaloriesConsumed += consume.calories;

            List<Workout> workouts = dbFunctions.getWorkoutsOnDate(userGUID, DateTime.Now);
            foreach (Workout workout in workouts) totalCaloriesBurned += workout.calories;

            CallResponse cr = new CallResponse();
            cr.response = "success";
            cr.consumed = totalCaloriesConsumed;
            cr.dailyBase = dbFunctions.getUserBase(userGUID);
            cr.exercise = totalCaloriesBurned;

            json = ser.Serialize(cr);
            context.Response.Clear();
            context.Response.ContentType = "application/json; charset=utf-8";
            context.Response.Write(json);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        public class CallResponse
        {
            public String response = "";
            public Int32 consumed = 0;
            public Int32 dailyBase = 0;
            public Int32 exercise = 0;
        }

    }
}