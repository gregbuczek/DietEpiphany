﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.IO;
using System.Text;

namespace DietInExerciseOut
{
    /// <summary>
    /// Summary description for AddWorkout
    /// </summary>
    public class AddWorkout : IHttpHandler
    {

        private DBFunctions dbFunctions = new DBFunctions();
        public void ProcessRequest(HttpContext context)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            String json = "";
            String userGUID = context.Request["userGUID"] ?? String.Empty;
            String exerciseID = context.Request["exerciseID"] ?? String.Empty;
            String duration = context.Request["duration"] ?? String.Empty;
            DateTime timeStamp = DateTime.Now;
            String dateTimeSerial = timeStamp.ToString("yyyyMMddhhmm");
            Exercise exercise = dbFunctions.getExercise(Convert.ToInt32(exerciseID));
            User user = dbFunctions.getUser(userGUID);
            Int32 calloriesBurned = Convert.ToInt32(Math.Round(Convert.ToInt32(exercise.calPerPound) * Convert.ToSingle(duration) * user.weight));

            Workout workout = new Workout();
            workout.workoutGUID = Guid.NewGuid().ToString();
            workout.userGUID = userGUID;
            workout.dateTimeStamp = timeStamp;
            workout.exerciseID = exercise.ID;
            workout.exerciseType = exercise.exerciseType;
            workout.duration = Convert.ToSingle(duration);
            workout.calories = calloriesBurned;

            dbFunctions.addWorkout(workout);

            var http = (HttpWebRequest)WebRequest.Create(new Uri(dbFunctions.MHEALTHBASE));
            //http.Accept = "application/json";
            http.ContentType = "text/json";
            http.Method = "POST";

            string jsonOut = "[" + new JavaScriptSerializer().Serialize(new
            {
                timestamp = dateTimeSerial,
                name = "workoutCalories",
                value = calloriesBurned
            }) + "]";
            ASCIIEncoding encoding = new ASCIIEncoding();
            Byte[] bytes = encoding.GetBytes(jsonOut);

            Stream newStream = http.GetRequestStream();
            newStream.Write(bytes, 0, bytes.Length);
            newStream.Close();

            var response = http.GetResponse();
            var stream = response.GetResponseStream();
            var sr = new StreamReader(stream);
            var content = sr.ReadToEnd();

            http = (HttpWebRequest)WebRequest.Create(new Uri(dbFunctions.MHEALTHBASE));
            //http.Accept = "application/json";
            http.ContentType = "text/json";
            http.Method = "POST";

            jsonOut = "[" + new JavaScriptSerializer().Serialize(new
            {
                timestamp = dateTimeSerial,
                name = "workoutDuration",
                value = duration
            }) + "]";
            encoding = new ASCIIEncoding();
            bytes = encoding.GetBytes(jsonOut);

            newStream = http.GetRequestStream();
            newStream.Write(bytes, 0, bytes.Length);
            newStream.Close();

            response = http.GetResponse();
            stream = response.GetResponseStream();
            sr = new StreamReader(stream);
            content = sr.ReadToEnd();

            http = (HttpWebRequest)WebRequest.Create(new Uri(dbFunctions.MHEALTHBASE));
            //http.Accept = "application/json";
            http.ContentType = "text/json";
            http.Method = "POST";

            jsonOut = "[" + new JavaScriptSerializer().Serialize(new
            {
                timestamp = dateTimeSerial,
                name = "workoutDescription",
                value = exercise.exerciseType
            }) + "]";
            encoding = new ASCIIEncoding();
            bytes = encoding.GetBytes(jsonOut);

            newStream = http.GetRequestStream();
            newStream.Write(bytes, 0, bytes.Length);
            newStream.Close();

            response = http.GetResponse();
            stream = response.GetResponseStream();
            sr = new StreamReader(stream);
            content = sr.ReadToEnd();



            CallResponse cr = new CallResponse();
            cr.response = "success";
            cr.calloriesBurned = calloriesBurned;
            json = ser.Serialize(cr);
            context.Response.Clear();
            context.Response.ContentType = "application/json; charset=utf-8";
            context.Response.Write(json);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
        public class CallResponse
        {
            public String response = "";
            public Int32 calloriesBurned = 0;
        }

    }
}