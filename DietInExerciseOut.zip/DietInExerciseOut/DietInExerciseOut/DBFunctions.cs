﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DietInExerciseOut
{
    public class DBFunctions
    {
        public String MHEALTHBASE = "https://api-mhealth.att.com/v2/health/source/8cce9acefe434ff3bacdef7c391620b4/data?oauth_token=mhealthv3-r3Mpbqv1S1SWAZisWMP8Ow-t7PTPv9lxZStIPNbY6xeA";
        public User getUser(String userGUID)
        {
            using (DataClassesDataContext db = new DataClassesDataContext())
            {
                return (from t in db.Users where t.userGUID == userGUID select t).First();
            }
        }
        public void updateUser(User user)
        {
            using (DataClassesDataContext db = new DataClassesDataContext())
            {
                User old = (from t in db.Users where t.userGUID == user.userGUID select t).First();
                old.age = user.age;
                old.height = user.height;
                old.sex = user.sex;
                old.userName = user.userName;
                old.mobile = user.mobile;
                old.weight = user.weight;
                db.SubmitChanges();
            }
        }


        public List<ABBREV> getFoods(String searchText)
        {
            using (DataClassesDataContext db = new DataClassesDataContext())
            {
                return (from t in db.ABBREVs where t.Shrt_Desc.Contains(searchText) select t).ToList();
            }
        }
        public ABBREV getFood(String ndbNo)
        {
            using (DataClassesDataContext db = new DataClassesDataContext())
            {
                return (from t in db.ABBREVs where t.NDB_No == ndbNo select t).First();
            }
        }

        public void addFood(ABBREV abbrev)
        {
            using (DataClassesDataContext db = new DataClassesDataContext())
            {
                db.ABBREVs.InsertOnSubmit(abbrev);
                db.SubmitChanges();
            }
        }

        public void addConsume(Consume consume)
        {
            using (DataClassesDataContext db = new DataClassesDataContext())
            {
                db.Consumes.InsertOnSubmit(consume);
                db.SubmitChanges();
            }
        }

        public List<Exercise> getExercises(String searchText)
        {
            using (DataClassesDataContext db = new DataClassesDataContext())
            {
                return (from t in db.Exercises where t.exerciseType.Contains(searchText) select t).ToList();
            }
        }
        public Exercise getExercise(Int32 id)
        {
            using (DataClassesDataContext db = new DataClassesDataContext())
            {
                return (from t in db.Exercises where t.ID == id select t).First();
            }
        }

        public Int32 addExercise(Exercise exercise)
        {
            using (DataClassesDataContext db = new DataClassesDataContext())
            {
                db.Exercises.InsertOnSubmit(exercise);
                db.SubmitChanges();
                return exercise.ID;
            }
        }

        public void addWorkout(Workout workout)
        {
            using (DataClassesDataContext db = new DataClassesDataContext())
            {
                db.Workouts.InsertOnSubmit(workout);
                db.SubmitChanges();
            }
        }
        public List<Consume> getConsumedOnDate(String userGUID, DateTime dateToCheck)
        {
            using (DataClassesDataContext db = new DataClassesDataContext())
            {
                return (from t in db.Consumes where t.userGUID == userGUID && t.dateTimeStamp.Year == dateToCheck.Year && t.dateTimeStamp.Month == dateToCheck.Month && t.dateTimeStamp.Day == dateToCheck.Day select t).ToList();
            }
        }
        public List<Workout> getWorkoutsOnDate(String userGUID, DateTime dateToCheck)
        {
            using (DataClassesDataContext db = new DataClassesDataContext())
            {
                return (from t in db.Workouts where t.userGUID == userGUID && t.dateTimeStamp.Year == dateToCheck.Year && t.dateTimeStamp.Month == dateToCheck.Month && t.dateTimeStamp.Day == dateToCheck.Day select t).ToList();
            }
        }
        public Int32 getUserBase(String userGUID)
        {
            using (DataClassesDataContext db = new DataClassesDataContext())
            {
                //For men: ((13.75 x w) + (5 x h) - (6.76 x a) + 66) * 1.2
                //For women: ((9.56 x w) + (1.85 x h) - (4.68 x a) + 655) * 1.2
                //w = weight in kg h = height in cm a = age

                User user = getUser(userGUID);
                Double weightInKilos = user.weight * 0.4535;
                Double heightInCM = user.height * 2.54;
                Double userBase;
                if (user.sex == "m")
                {
                    userBase = ((13.75 * weightInKilos) + (5 * heightInCM) - (6.76 * user.age) + 66) * 1.2;
                }
                else
                {
                    userBase = ((9.56 * weightInKilos) + (1.85 * heightInCM) - (4.68 * user.age) + 655) * 1.2;
                }
                return Convert.ToInt32(Math.Round(userBase));
            }
        }

    }
}