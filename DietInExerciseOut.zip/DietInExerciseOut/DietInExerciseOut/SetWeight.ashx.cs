﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.IO;
using System.Text;

namespace DietInExerciseOut
{
    /// <summary>
    /// Summary description for SetWeight
    /// </summary>
    public class SetWeight : IHttpHandler
    {
        private DBFunctions dbFunctions = new DBFunctions();
        public void ProcessRequest(HttpContext context)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            String json = "";
            String userGUID = context.Request["userGUID"] ?? String.Empty;
            String weight = context.Request["weight"] ?? String.Empty;

            User user = dbFunctions.getUser(userGUID);
            user.weight = Convert.ToInt32(weight);
            dbFunctions.updateUser(user);

            String dateTimeSerial = DateTime.Now.ToString("yyyyMMddhhmm");
            var http = (HttpWebRequest)WebRequest.Create(new Uri(dbFunctions.MHEALTHBASE));
            //http.Accept = "application/json";
            http.ContentType = "text/json";
            http.Method = "POST";
            
            string jsonOut = "[" + new JavaScriptSerializer().Serialize(new
            {
                timestamp = dateTimeSerial,
                name = "weight",
                unit = "lb",
                value = weight
            }) + "]";
            //string parsedContent = "[{\"timestamp\":\"201109131223\", \"name\":\"weight\", \"unit\":\"pound\", \"value\":195}]";
            ASCIIEncoding encoding = new ASCIIEncoding();
            Byte[] bytes = encoding.GetBytes(jsonOut);

            Stream newStream = http.GetRequestStream();
            newStream.Write(bytes, 0, bytes.Length);
            newStream.Close();

            var response = http.GetResponse();

            var stream = response.GetResponseStream();
            var sr = new StreamReader(stream);
            var content = sr.ReadToEnd();
            String x = "";
            
            
            
            
            
            SimpleResponse s = new SimpleResponse();
            s.response = "success";
            json = ser.Serialize(s);
            context.Response.Clear();
            context.Response.ContentType = "application/json; charset=utf-8";
            context.Response.Write(json);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        public class SimpleResponse
        {
            public String response = "success";
        }

    }
}