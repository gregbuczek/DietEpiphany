﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DBFunctions
/// </summary>
public class DBFunctions
{
	public DBFunctions()
	{

    }
    public User getUser(String userGUID)
    {
        using (DataClassesDataContext db = new DataClassesDataContext())
        {
            return (from t in db.Users where t.userGUID == userGUID select t).First();
        }
    }
    public List<Consume> getConsumedOnDate(String userGUID, DateTime dateToCheck)
    {
        using (DataClassesDataContext db = new DataClassesDataContext())
        {
            return (from t in db.Consumes where t.userGUID == userGUID && t.dateTimeStamp.Year == dateToCheck.Year && t.dateTimeStamp.Month == dateToCheck.Month && t.dateTimeStamp.Day == dateToCheck.Day select t).ToList();
        }
    }
    public List<Workout> getWorkoutsOnDate(String userGUID, DateTime dateToCheck)
    {
        using (DataClassesDataContext db = new DataClassesDataContext())
        {
            return (from t in db.Workouts where t.userGUID == userGUID && t.dateTimeStamp.Year == dateToCheck.Year && t.dateTimeStamp.Month == dateToCheck.Month && t.dateTimeStamp.Day == dateToCheck.Day select t).ToList();
        }
    }
    public Int32 getUserBase(String userGUID)
    {
        using (DataClassesDataContext db = new DataClassesDataContext())
        {
            //For men: ((13.75 x w) + (5 x h) - (6.76 x a) + 66) * 1.2
            //For women: ((9.56 x w) + (1.85 x h) - (4.68 x a) + 655) * 1.2
            //w = weight in kg h = height in cm a = age

            User user = getUser(userGUID);
            Double weightInKilos = user.weight * 0.4535;
            Double heightInCM = user.height * 2.54;
            Double userBase;
            if (user.sex == "m")
            {
                userBase = ((13.75 * weightInKilos) + (5 * heightInCM) - (6.76 * user.age) + 66) * 1.2;
            }
            else
            {
                userBase = ((9.56 * weightInKilos) + (1.85 * heightInCM) - (4.68 * user.age) + 655) * 1.2;
            }
            return Convert.ToInt32(Math.Round(userBase));
        }
    }
}